if (document.getElementById('XenForo'))
{
    if (document.getElementById('XenForo').classList.contains('LoggedIn'))
    {
        chrome.runtime.sendMessage({'url': document.getElementsByTagName('base')[0].href, 'title': document.getElementsByClassName('boardTitle')[0].innerText, 'image': document.querySelector('link[rel="apple-touch-icon"]').href}, function(response) {
        });
    }
    if (document.getElementsByClassName('sidebar').length > 0)
    {
        var sidebar = document.getElementsByClassName('sidebar')[0];
        chrome.runtime.sendMessage({'fetch': 'ad', 'url': document.getElementsByTagName('base')[0].href}, function(response) {
        });
    }
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request['ad'])
    {
        var advert = document.createElement("div");
        advert.innerHTML = request.ad;
        sidebar.appendChild(advert);
    }
});